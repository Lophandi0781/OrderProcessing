﻿using OrderProcessing.DAO;

namespace OrderProcessing.BAL.Orders
{
    public  class MemberShipOrUpgarde : IOrderPayment
    {
        /// <summary>
        /// ProceessOrder
        /// </summary>
        public void ProceessOrder()
        {
            SendEmailForActivationOrUpgrade.SendEmailForActivationOrUpgradeToOwner();
        }
    }
}
