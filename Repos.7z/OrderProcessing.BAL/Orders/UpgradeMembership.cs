﻿using OrderProcessing.DAO;
namespace OrderProcessing.BAL.Orders
{
    public class UpgradeMembership : IOrderPayment
    {
        public void ProceessOrder()
        {
            UpgradeMemberships.UpgradeUserMembeships();
        }
    }
}
