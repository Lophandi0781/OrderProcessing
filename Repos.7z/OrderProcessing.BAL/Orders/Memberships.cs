﻿using OrderProcessing.DAO;
namespace OrderProcessing.BAL.Orders
{
  public  class Memberships : IOrderPayment
    {
        public void ProceessOrder()
        {
            ActiveMemberships.ActiveUserMemebrShip();
        }
    }
}
