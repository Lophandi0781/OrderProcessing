﻿using OrderProcessing.DAO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderProcessing.BAL.Orders
{
  public  class Videos : IOrderPayment
    {
        /// <summary>
        /// VideoName
        /// </summary>
        public string VideoName { get; set; } = string.Empty;

        /// <summary>
        /// ProceessOrder
        /// </summary>
        public void ProceessOrder()
        {
            this.VideoName = GetVideoName();
            VedioPayment.AddFreeAdds(VideoName);
        }

        /// <summary>
        /// GetVideoName
        /// </summary>
        /// <returns></returns>
        private string GetVideoName()
        {
            return "Learning to Ski";
        }
    }
}
