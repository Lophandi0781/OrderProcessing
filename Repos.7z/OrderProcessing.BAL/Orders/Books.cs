﻿using OrderProcessing.DAO;
namespace OrderProcessing.BAL.Orders
{
    public class Books : IOrderPayment
    {
        /// <summary>
        /// ProceessOrder
        /// </summary>
        public void ProceessOrder()
        {
            CreateDuplicateSlip.CreateDuplicateSlipForTheRoyalDepartment();
        }
    }
}
