﻿using OrderProcessing.DAO;
namespace OrderProcessing.BAL.Orders
{
    public class PhysicalProductOrBook : IOrderPayment
    {
        /// <summary>
        /// ProceessOrder
        /// </summary>
        public void ProceessOrder()
        {
            GenerateCommisionPayment.GenerateCommissionToAgent();
        }
    }
}
