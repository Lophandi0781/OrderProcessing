﻿using OrderProcessing.DAO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderProcessing.BAL.Orders
{
    public class PhysicalProducts : IOrderPayment
    {
        /// <summary>
        /// ProceessOrder
        /// </summary>
        public void ProceessOrder()
        {
            GeneratePackingSlip.GenerateSlip();
        }
    }
}
