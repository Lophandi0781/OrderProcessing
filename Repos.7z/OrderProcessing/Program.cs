﻿using OrderProcessing.BAL;
using OrderProcessing.Common.Helper;
using OrderProcessing.Factory;
using System;


namespace OrderProcessing
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Order Processing System");
            Console.WriteLine("=============================================");
            Console.WriteLine("1.Payment is for a physical product");
            Console.WriteLine("2.Payment is for a book");
            Console.WriteLine("3.Payment is for a membership");
            Console.WriteLine("4.Payment is an upgrade to a membership");
            Console.WriteLine("5.Payment is for a membership or upgrade");
            Console.WriteLine("6.Payment is for the video");
            Console.WriteLine("7.Payment is for a physical product or a book");
            Console.WriteLine("===============================================");
            try
            {
                Console.WriteLine("Enter your input(1-7)?");
                string input = Console.ReadLine();
                if (!string.IsNullOrEmpty(input))
                {
                    if (ValidateInput.ValidateUserInput(input))
                    {
                        IOrderPayment orderPayment = null;
                        OrderEnums orderEnums = GetCurrentEnumObject.GetEnumVal(input);
                       
                        orderPayment = OrderFactory.GetCurrentObject(orderEnums);
                        orderPayment.ProceessOrder();                       
                    }
                }
                else
                {
                    Console.WriteLine("Invalid Input");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
