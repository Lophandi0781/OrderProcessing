﻿using OrderProcessing.Factory;
using System;
namespace OrderProcessing
{
  partial  class GetCurrentEnumObject
    {
        /// <summary>
        /// GetEnumVal
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static OrderEnums GetEnumVal(string input)
        {
            OrderEnums orderEnums = OrderEnums.PhysicalProduct;
            switch (input) {
                case "1":
                    orderEnums = OrderEnums.PhysicalProduct;
                    break;
                case "2":
                    orderEnums = OrderEnums.Books;
                    break;
                case "3":
                    orderEnums = OrderEnums.Memberships;
                    break;
                case "4":
                    orderEnums = OrderEnums.UpgradeMemberships;
                    break;
                case "5":
                    orderEnums = OrderEnums.UpgradeOrMemberships;
                    break;
                case "6":
                    orderEnums = OrderEnums.Videos;
                    break;
                case "7":
                    orderEnums = OrderEnums.PhysicalProductOrBook;
                    break;
            }

            return orderEnums;

        }
    }
}
