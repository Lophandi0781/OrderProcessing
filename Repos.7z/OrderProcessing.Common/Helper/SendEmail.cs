﻿using System;

namespace OrderProcessing.Common.Helper
{
    public  class SendEmail
    {
        /// <summary>
        /// SendEmailToOwner
        /// </summary>
        public static void SendEmailToOwner()
        {
            Console.WriteLine("Email Sent");
        }
    }
}
