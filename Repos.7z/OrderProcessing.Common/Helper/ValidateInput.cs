﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderProcessing.Common.Helper
{
    public class ValidateInput
    {
        /// <summary>
        /// ValidateUserInput
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static bool ValidateUserInput(string input)
        {
            

            switch (input)
            {
                case "1":
                case "2":
                case "3":
                case "4":
                case "5":
                case "6":
                case "7":
                    return true;
                default:
                    return false;
            }
        }
    }
}
