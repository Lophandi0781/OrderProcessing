﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OrderProcessing.Common.Helper;

namespace OrderProcessing.UnitTest
{
    [TestClass]
    public class UnitTestUserInput
    {
        [TestMethod]
        public void TestUserInupt1()
        {
            string input1 = "1";
            var actualValue =  ValidateInput.ValidateUserInput(input1);
            var expectedValue = true;
            Assert.AreEqual(actualValue, expectedValue);            
        }

        [TestMethod]
        public void TestUserInupt2()
        {
        
            string input2 = "8";
            var actualValue1 = ValidateInput.ValidateUserInput(input2);
            var expectedValue1 = true;
            Assert.AreEqual(actualValue1, expectedValue1);
        }
    }
}
