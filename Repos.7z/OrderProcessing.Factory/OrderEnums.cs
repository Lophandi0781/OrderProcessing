﻿namespace OrderProcessing.Factory
{
    /// <summary>
    /// OrderEnums
    /// </summary>
    public enum OrderEnums
    {
        PhysicalProduct,
        Books,
        Memberships,
        UpgradeMemberships,
        UpgradeOrMemberships,
        Videos,
        PhysicalProductOrBook

    }
}
