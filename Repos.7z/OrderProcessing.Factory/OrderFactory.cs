﻿using OrderProcessing.BAL;
using OrderProcessing.BAL.Orders;

namespace OrderProcessing.Factory
{
    public class OrderFactory
    {
        /// <summary>
        /// GetCurrentObject
        /// </summary>
        /// <param name="orderEnums"></param>
        /// <returns></returns>
        public static IOrderPayment GetCurrentObject(OrderEnums orderEnums)
        {
            IOrderPayment orderPayment = null;
            switch (orderEnums)
            {
                case OrderEnums.PhysicalProduct:
                    orderPayment = new PhysicalProducts();
                    break;
                case OrderEnums.Memberships:
                    orderPayment = new Memberships();
                    break;
                case OrderEnums.PhysicalProductOrBook:
                    orderPayment = new PhysicalProductOrBook();
                    break;
                case OrderEnums.Books:
                    orderPayment = new Books();
                    break;
                case OrderEnums.UpgradeMemberships:
                    orderPayment = new UpgradeMembership();
                    break;
                case OrderEnums.UpgradeOrMemberships:
                    orderPayment = new Memberships();
                    break;
                case OrderEnums.Videos:
                    orderPayment = new Videos();
                    break;
            }
            return orderPayment;
        }
    }
}
