﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderProcessing.DAO
{
   public class CreateOrUpgrade
    {
        /// <summary>
        /// CreateOrUpgradeMemberShip
        /// </summary>
        /// <param name="input"></param>
        public static void CreateOrUpgradeMemberShip(int  input = 0)
        {
            if (input == 1)
            {
                Console.WriteLine("Membership created");
            }
            else if(input ==2)
            {
                Console.WriteLine("Membership Upgraded");
            }
            else
            {
                Console.WriteLine("No Action");
            }
        }
    }
}
