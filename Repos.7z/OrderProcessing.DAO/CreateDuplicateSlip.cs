﻿using System;

namespace OrderProcessing.DAO
{
    public class CreateDuplicateSlip
    {
        /// <summary>
        /// CreateDuplicateSlipForTheRoyalDepartment
        /// </summary>
        public static void CreateDuplicateSlipForTheRoyalDepartment()
        {
            Console.WriteLine("Duplicate Slip created");
        }
    }
}
