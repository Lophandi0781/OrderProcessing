﻿using System;

namespace OrderProcessing.DAO
{
    public  class ActiveMemberships
    {
        public  static void ActiveUserMemebrShip()
        {
            Console.WriteLine("Membership Activated");
        }
    }
}
