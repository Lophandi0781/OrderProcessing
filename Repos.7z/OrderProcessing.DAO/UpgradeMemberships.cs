﻿using System;

namespace OrderProcessing.DAO
{
    public class UpgradeMemberships
    {
        /// <summary>
        /// UpgradeUserMembeships
        /// </summary>
        public static void UpgradeUserMembeships()
        {
            Console.WriteLine("MemberShip Upgraded");
        }
    }
}
