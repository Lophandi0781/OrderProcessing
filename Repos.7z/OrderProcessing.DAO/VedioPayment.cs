﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderProcessing.DAO
{
  public class VedioPayment
    {
        /// <summary>
        /// AddFreeAdds
        /// </summary>
        /// <param name="videoName"></param>
        public static void AddFreeAdds(string videoName="")
        {
            if(videoName== "Learning to Ski")
            {
                Console.WriteLine("First Aid add added");
            }
            else
            {
                Console.WriteLine("No Action");
            }
        }
    }
}
