﻿using System;
using OrderProcessing.Common.Helper;
namespace OrderProcessing.DAO
{
    public class SendEmailForActivationOrUpgrade
    {
        /// <summary>
        /// SendEmailForActivationOrUpgradeToOwner
        /// </summary>
        public static void SendEmailForActivationOrUpgradeToOwner()
        {
            try
            {
                Console.WriteLine("Sending Email..................");
                SendEmail.SendEmailToOwner();
                Console.WriteLine("Email Sent..................");
            }
            catch
            {
                Console.WriteLine("Error While sending email");
            }
        }
    }
}

