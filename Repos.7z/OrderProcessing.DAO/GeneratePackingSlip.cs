﻿using System;

namespace OrderProcessing.DAO
{
    public class GeneratePackingSlip
    {
        /// <summary>
        /// GenerateSlip
        /// </summary>
        public static void GenerateSlip()
        {
            Console.WriteLine("Slips has been generated");
        }
    }
}
