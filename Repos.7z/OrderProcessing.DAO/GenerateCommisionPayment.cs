﻿using System;
namespace OrderProcessing.DAO
{
    public class GenerateCommisionPayment
    {
        /// <summary>
        /// GenerateCommissionToAgent
        /// </summary>
        public static void GenerateCommissionToAgent()
        {
            Console.WriteLine("Commission payment done to agent");
        }
    }
}
